#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#define KEY (ftok("semabinit.c",'a'))
int main()
{
   int id; 
   union semun {
      int val;
      struct semid_ds *buf;
      ushort * array;
   } argument;
   argument.val = 0;
   id = semget(KEY, 1, 0666 | IPC_CREAT);
   semctl(id, 0, SETVAL, argument);
}

