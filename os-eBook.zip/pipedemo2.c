#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

#define  oops(m,x)	{ perror(m); exit(x); }

main()
{
	int  pipefd[2],len,read_len;
  char  buf[BUFSIZ];
  
  if ( pipe( pipefd ) == -1 )
    oops("cannot get a pipe", 1);
  
  switch( fork() ){
    case -1:
      oops("cannot fork", 2);
      
    case 0:      
      len = strlen("I want a cookie\n");
      while ( 1 ){
        if (write( pipefd[1], "I want a cookie\n", len) != len )
          oops("write", 3);
        sleep(5);
      }
      
    default:    
      len = strlen( "testing..\n" );
      while ( 1 ){
        if ( write( pipefd[1], "testing..\n", len)!=len )
          oops("write", 4);
        sleep(1);
        read_len = read( pipefd[0], buf, BUFSIZ );
        if ( read_len <= 0 )
          break;
        write( 1 , buf, read_len );
      }
  }
}
