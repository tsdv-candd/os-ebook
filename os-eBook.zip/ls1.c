#include	<stdio.h>
#include	<sys/types.h>
#include	<dirent.h>


main()
{
	DIR		*dir_ptr;		/* the directory */
	struct dirent	*direntp;		/* each entry	 */

	if ( ( dir_ptr = opendir( "." ) ) == NULL )
		fprintf(stderr,"ls1: cannot open .\n");
	else
	{
		while ( ( direntp = readdir( dir_ptr ) ) != NULL )
			printf("%s\n", direntp->d_name );
		closedir(dir_ptr);
	}
}
