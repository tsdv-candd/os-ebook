#include	<stdio.h>
#include	<sys/shm.h>
#include	<time.h>
#define	MEM_KEY	(ftok("shm.c",'a'))
main()
{
  int seg_id, *value, n;
  seg_id = shmget(MEM_KEY, sizeof(int), IPC_CREAT|0777 );
  value= shmat( seg_id, NULL, 0 );
  *value=1;
  for(n=0; n<5; n++ )
  {
    printf("value=%d\n Press key to continue\n",*value); 
    scanf("%*c");
    *value=*value+1;
  }		
  shmctl( seg_id, IPC_RMID, NULL );
}
