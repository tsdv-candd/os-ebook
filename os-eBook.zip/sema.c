#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#define KEY (ftok("semabinit.c",'a'))
int main()
{
   int id;
   struct sembuf operations[1];
   id = semget(KEY, 1, 0666);
   printf("Program sema about to do an UP-operation. \n");
   operations[0].sem_num = 0;
   operations[0].sem_op = 1;
   operations[0].sem_flg = 0;
   semop(id, operations, 1);
   printf("Successful UP-operation by program sema.\n");
}
