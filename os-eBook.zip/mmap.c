#include<unistd.h>
#include<sys/mman.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

main()
{
    int fd;
    char * buf;
    struct stat sbuf;

    fd=open("mmap.c",O_RDONLY);
    fstat(fd,&sbuf);
    buf=mmap(0,sbuf.st_size,PROT_READ,MAP_SHARED,fd,0);
    write(0,buf,sbuf.st_size);
    munmap(buf,sbuf.st_size);
    close(fd);
}



